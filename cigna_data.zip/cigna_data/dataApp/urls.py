
from django.urls import path
from dataApp.views import *

urlpatterns = [
    # path('admin/', admin.site.urls),
    path('',index,name='index')
]
